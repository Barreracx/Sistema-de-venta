
package Modelo;

public class Productos {
    private int id;
    private String Codigo;
    private String Nombre;
    private String Proveedor;
    private int Stock;
    private double Precio;

    public Productos() {
    }

    public Productos(int id, String Codigo, String Nombre, String Proveedor, int Stock, double Precio) {
        this.id = id;
        this.Codigo = Codigo;
        this.Nombre = Nombre;
        this.Proveedor = Proveedor;
        this.Stock = Stock;
        this.Precio = Precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getProveedor() {
        return Proveedor;
    }

    public void setProveedor(String Proveedor) {
        this.Proveedor = Proveedor;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }

    public double getPrecio() {
        return Precio;
    }

    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }
    
    
    
}
