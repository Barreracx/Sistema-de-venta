
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
public class loginDao {
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Conexion cn = new Conexion();
    public login log(String Correo, String Password){
        login l = new login();
        String sql = "SELECT * FROM usuarios Where Correo = ?  AND Password = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, Correo);
            ps.setString(2, Password);
            rs = ps.executeQuery();
            if (rs.next()) {
                l.setCedula(rs.getInt("Cedula"));
                l.setNombre(rs.getString("Nombre"));
                l.setCorreo(rs.getString("Correo"));
                l.setPassword(rs.getString("Password"));
                
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return l;
    
    }
    
    
}

   
    

