/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.ResultSet;


/**
 *
 * @author ASUS Laptop
 */
public class ClienteDao {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    public boolean RegistrarCliente (Cliente cl){
     String sql = "INSERT INTO clientes (Cedula, nombre, Direccion, Celular) VALUES (?,?,?,?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, cl.getCedula());
            ps.setString(2, cl.getNombre());
            ps.setString(3, cl.getDireccion());
            ps.setInt(4, cl.getCelular());
            ps.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
            return false;
            
        }finally{
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println(e.toString());
            }
        }
        
    }
    
    public List ListarCliente(){
    List<Cliente> ListaCl = new ArrayList();
    String sql = "SELECT * FROM clientes";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {    
                Cliente cl = new Cliente();
                cl.setId(rs.getInt("id"));
                cl.setCedula(rs.getInt("Cedula"));
                cl.setNombre(rs.getString("Nombre"));
                cl.setDireccion(rs.getString("Direccion"));
                cl.setCelular(rs.getInt("Celular"));
                ListaCl.add(cl);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return ListaCl;
    }
    public boolean EliminarCliente(int id){
        String sql = "DELETE FROM clientes WHERE id = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
    }
    
    public boolean ModificarCliente(Cliente cl){
        String sql = "UPDATE clientes SET Cedula=?,Nombre= ?, Direccion=?, Celular=? WHERE id=?";
        try {
            ps = con.prepareStatement(sql);
       
            ps.setInt(1, cl.getCedula());
            ps.setString(2, cl.getNombre());
            ps.setString(3, cl.getDireccion());
            ps.setInt(4, cl.getCelular());
            ps.setInt(5, cl.getId());
            ps.execute();
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }finally{
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println(e.toString());
            }
        }
        return false;
        
    }
    
    public Cliente Buscarcliente(int Cedula){
        Cliente cl = new Cliente();
        String sql = "SELECT * FROM clientes Where Cedula = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, Cedula);
            rs = ps.executeQuery();
            if (rs.next()) {
                cl.setNombre(rs.getString("Nombre"));
                cl.setDireccion(rs.getString("Direccion"));
                cl.setCelular(rs.getInt("Celular"));
               
            }
        
        }catch (SQLException e) {
                System.out.println(e.toString());
        }
        return cl;
    }
}




